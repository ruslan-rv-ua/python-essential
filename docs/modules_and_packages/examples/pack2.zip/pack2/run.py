﻿# Приклад використання пакетів

# Імпортування  модуля application.tests
import application.tests

application.tests.run_app_test()