from subfolder.module1 import hello

hello()