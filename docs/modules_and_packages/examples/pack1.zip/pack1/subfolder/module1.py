def hello():
	print('Module 1 is here!')