def hello():
	print('Module 2 is here!')