__all__ = ['wave_to_mp3', 'mp3_to_wave']

def wave_to_mp3(data):
	print('Converting wave data to mp3')
	
def mp3_to_wave(data):
	print('Converting mp3 data to wave')